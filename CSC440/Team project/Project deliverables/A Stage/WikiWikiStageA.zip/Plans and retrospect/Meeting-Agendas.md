# Stage A/B Meeting Agendas

* Team: WikiWiki
* Members: Ryan Guard, Elizabeth Gieske, Ronnie Hoover, Liam Tiemon, Christopher Groppe 
* Date: 04/19/2018

### Meetings

* 1st meeting: March 29, 2018
	* Everyone Attended
	* We decided on Stage B feature
	* Edited current team wiki page
	* Read through html of wiki
	* Further researched how content (.md) is stored

Attendees: Elizabeth Gieske, Ryan Guard, Liam Tiemon, Ronnie Hoover

* 2nd meeting:  April 2, 2018
	* Everyone Attended
	* Online figuring out how we would break up our feature (storing content history for the website and allowing for reverts and recovery of pages).
	* Delegated tasks out for the project.
	* Decided to meet on the 7th to start working together to allow for pair programming if necessary and maintain a consistent vision for how our feature would look.

* 3rd meeting: April 5, 2018
	* Everyone Attended
	* Two future meeting dates were created
	* One meeting Saturday for clarifying and working on Stage B
	* And another Longer meeting on Monday to attempt to get as much done of stage B as we can together as possible
	
* 4th meeting: April 7, 2018
	* Ryan Guard, Elizabeth Gieske, Christopher Groppe attended
	* Established features
	* Architected out solution for feature
	* started/finished documentation of parts
	* modularized features.
	* further established objectives of modules.

* 5th meeting: April 9, 2018
	* Ryan Guard, Elizabeth Gieske, Liam Tiemon, Christopher Groppe(online) attended
	* Worked on Stage B in pair programming. Started scoping out what we'd need to do for Stage A of the assignment.
\newpage
	
* 6th meeting: April 13, 2018
	* Ryan Guard, Elizabeth Gieske, Liam Tiemon, Christopher Groppe(online) attended
	* Completed our developments of our modules in stage B. If modules weren't done by end of meeting it was agreed to have them done by monday where we'd put it all together and test end-to-end.
	* Further documentation made.

* 7th meeting: April 16, 2018
	* Everyone attended
	* Integrated modules. Finalized testing and documentation for stage B.
	* Start working towards completing stage A (hopefully finished).
	
* 8th meeting: April 17, 2018
    * Completed Stage A requirements
    * Completed all testing
    * Finished documentation
    * Group will do final checks and submissions tomorrow
	
* Retrospective: April 18, 2018
    * Everyone Attended 
	* Final review of Deliverables
	* Assessment on current sprint.
	



