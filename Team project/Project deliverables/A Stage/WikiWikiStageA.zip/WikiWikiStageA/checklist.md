Please check (O) when you added the expected outputs in the directory.
Please check (X) with explanations why you don't/can't. 

# Plans and retrospect

1. (O) Schedule (file or screen capture)
2. (O) Meeting agenda files
3. (O) Rules collection file
4. (O) Retrospect meeting file

# Results

1. (O) Member1 (Ryan Guard) implemented a feature and made required documents.
2. (O) Member2 (Elizabeth Gieske) implemented a feature and made required documents.
3. (O) Member3 (Liam Tiemon) implemented a feature and made required documents.
4. (O) Member4 (Christopher Groppe) implemented a feature and made required documents.
5. (O) Member5 (Ronnie Hoover) implemented a feature and made required documents.