## Retro
* Members: Ryan Guard, Elizabeth Gieske, Ronnie Hoover, Liam Tiemon, Christopher Groppe 
* Date: 04/19/2018

#### What we did well
1. Communicated decently well about schedules, ability to show up to meetings and if meeting was impossible contact over the internet was made
2. Stuck relatively close to the schedule
3. High meeting attendance for the large amount of meetings we had
4. Adapted to changing requirements well.
5. Distributed work relatively evenly based on bandwidth to work on project.
6. Great teamwork in pair programming meetings

#### Problems faced
1. Schedules didn't always line up/ finding convenient meeting times was occasionally difficult
2. Everyone was rather busy during this phase due to it being the end of the semester
3. We could've started our schedule earlier to alleviate some of the stressors.

#### What can improve
1. Use the full time available to keep project low stress
2. Communication line could be checked more often.